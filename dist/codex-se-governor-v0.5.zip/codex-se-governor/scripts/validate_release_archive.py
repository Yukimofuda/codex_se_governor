#!/usr/bin/env python3
"""Validate that a release zip does not contain generated artifacts."""

from pathlib import Path
import sys
import zipfile

BAD_DIRS = {".pytest_cache", "__pycache__", "__MACOSX", ".venv", "venv", "env"}
BAD_FILES = {".DS_Store"}
BAD_SUFFIXES = {".pyc", ".pyo", ".pyd"}


def bad_entry(name):
    parts = Path(name).parts
    if any(part in BAD_DIRS for part in parts):
        return True
    leaf = parts[-1] if parts else name
    return leaf in BAD_FILES or leaf.endswith(tuple(BAD_SUFFIXES))


def main(argv):
    if len(argv) != 2:
        print("Usage: python scripts/validate_release_archive.py dist/codex-se-governor-v0.5.zip")
        return 2
    archive_path = Path(argv[1])
    if not archive_path.exists():
        print(f"FAIL missing archive: {archive_path}")
        return 1
    failures = []
    with zipfile.ZipFile(archive_path) as archive:
        for name in archive.namelist():
            if bad_entry(name):
                failures.append(f"generated artifact in archive: {name}")
    if failures:
        print("FAIL")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
