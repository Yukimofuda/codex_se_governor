#!/usr/bin/env python3
"""Run pytest without leaving generated cache artifacts behind."""

from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def run(command, env):
    print(f"$ {' '.join(command)}")
    return subprocess.run(command, cwd=ROOT, text=True, env=env, check=False)


def main(argv=None):
    args = list(argv or sys.argv[1:])
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    pytest_command = [sys.executable, "-m", "pytest", "-p", "no:cacheprovider", *args]
    pytest_result = run(pytest_command, env)
    cleanup_result = run([sys.executable, "scripts/clean_artifacts.py"], env)
    clean_result = run([sys.executable, "scripts/validate_clean_package.py"], env)
    if pytest_result.returncode != 0:
        print("FAIL pytest failed")
        return pytest_result.returncode
    if cleanup_result.returncode != 0:
        print("FAIL cleanup failed")
        return cleanup_result.returncode
    if clean_result.returncode != 0:
        print("FAIL clean package validation failed after tests")
        return clean_result.returncode
    print("PASS tests completed without retained generated artifacts")
    return 0


if __name__ == "__main__":
    sys.exit(main())
