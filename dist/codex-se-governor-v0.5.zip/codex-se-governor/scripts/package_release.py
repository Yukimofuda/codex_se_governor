#!/usr/bin/env python3
"""Create a clean release zip archive."""

from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
ARCHIVE = DIST / "codex-se-governor-v0.5.zip"
SKIP_DIRS = {".git", ".pytest_cache", "__pycache__", "__MACOSX", ".venv", "venv", "env", "dist"}
SKIP_FILES = {".DS_Store"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".pyd", ".log"}


def include(path):
    rel = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if path.name in SKIP_FILES or path.suffix in SKIP_SUFFIXES:
        return False
    if len(rel.parts) >= 2 and rel.parts[0] == "tasks" and rel.parts[1].endswith("-smoke"):
        return False
    return path.is_file()


def main(argv=None):
    DIST.mkdir(exist_ok=True)
    if ARCHIVE.exists():
        ARCHIVE.unlink()
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            if include(path):
                archive.write(path, Path("codex-se-governor") / path.relative_to(ROOT))
    print(f"PASS created {ARCHIVE.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
