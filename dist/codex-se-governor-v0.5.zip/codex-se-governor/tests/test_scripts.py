from pathlib import Path
import json
import shutil
import subprocess
import sys
import zipfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def copy_project(tmp_path):
    target = tmp_path / "repo"
    shutil.copytree(
        PROJECT_ROOT,
        target,
        ignore=shutil.ignore_patterns(
            ".git",
            ".pytest_cache",
            "__pycache__",
            "tests",
            "tasks",
        ),
    )
    return target


def run_script(repo, script, *args):
    return subprocess.run(
        [sys.executable, str(repo / "scripts" / script), *args],
        cwd=repo,
        text=True,
        capture_output=True,
        check=False,
    )


def test_se_gate_passes_on_complete_project(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "se_gate.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_se_gate_fails_when_required_artifact_missing(tmp_path):
    repo = copy_project(tmp_path)
    (repo / "AGENTS.md").unlink()
    result = run_script(repo, "se_gate.py")
    assert result.returncode == 1
    assert "missing required artifact: AGENTS.md" in result.stdout


def test_se_gate_fails_on_dangerous_text(tmp_path):
    repo = copy_project(tmp_path)
    dangerous = "api" + "_key = " + '"abcdef123456"'
    (repo / "danger.txt").write_text(dangerous, encoding="utf-8")
    result = run_script(repo, "se_gate.py")
    assert result.returncode == 1
    assert "dangerous text" in result.stdout
    assert "danger.txt" in result.stdout


def test_validate_pr_checklist_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_pr_checklist.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_pr_checklist_fails_for_malformed_template(tmp_path):
    repo = copy_project(tmp_path)
    pr_template = repo / ".github" / "pull_request_template.md"
    pr_template.write_text("# Pull Request\n\n## Testing\n", encoding="utf-8")
    result = run_script(repo, "validate_pr_checklist.py")
    assert result.returncode == 1
    assert "missing PR checklist item: Requirement trace" in result.stdout
    assert "missing PR checklist item: Rollback" in result.stdout


def test_validate_traceability_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_traceability.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_traceability_fails_when_chapter_missing(tmp_path):
    repo = copy_project(tmp_path)
    matrix = repo / "docs" / "software-engineering" / "18_TRACEABILITY_MATRIX.md"
    text = matrix.read_text(encoding="utf-8")
    matrix.write_text(text.replace("17. Revision", "17. Review Summary"), encoding="utf-8")
    result = run_script(repo, "validate_traceability.py")
    assert result.returncode == 1
    assert "missing chapter: 17. Revision" in result.stdout


def test_generate_task_scaffold_creates_expected_files(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "generate_task_scaffold.py", "feature-login-rate-limit")
    assert result.returncode == 0
    task_dir = repo / "tasks" / "feature-login-rate-limit"
    expected = {
        "REQUIREMENTS.md",
        "USER_STORY.md",
        "ANALYSIS.md",
        "DESIGN.md",
        "ADR.md",
        "TEST_PLAN.md",
        "TEST_CASE_MATRIX.md",
        "RISK_REGISTER.md",
        "SECURITY_REVIEW.md",
        "AI_USAGE_REVIEW.md",
        "PROCESS_COMPLIANCE_REPORT.md",
        "DEPLOYMENT_PLAN.md",
        "MAINTENANCE_TASK.md",
        "FINAL_REPORT.md",
    }
    assert expected == {path.name for path in task_dir.iterdir()}
    assert "Created tasks/feature-login-rate-limit" in result.stdout


def test_generate_task_scaffold_rejects_bad_arguments(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "generate_task_scaffold.py")
    assert result.returncode == 2
    assert "Usage:" in result.stdout


def test_scan_for_engineering_smells_warns_without_id_false_positives(tmp_path):
    repo = copy_project(tmp_path)
    sample = repo / "sample.py"
    dynamic_call = "ev" + "al("
    sample.write_text(
        "\n".join(
            [
                "# FIX" + "ME check edge case",
                "to" + "ken = 'abcdef123456'",
                f"{dynamic_call}'1 + 1')",
                "timeout_seconds = " + "12" + "34" + "5",
                "# FR-001 AC-001 TC-001 R-001 NFR-001 are trace IDs",
            ]
        ),
        encoding="utf-8",
    )
    result = run_script(repo, "scan_for_engineering_smells.py", str(sample))
    assert result.returncode == 0
    todo_label = "TO" + "DO" + "/FIX" + "ME"
    assert todo_label in result.stdout
    assert "hardcoded secret" in result.stdout
    assert "dynamic code execution" in result.stdout
    expected_magic = "possible magic number " + "12" + "34" + "5"
    assert expected_magic in result.stdout
    false_positive = "possible magic number " + "00" + "1"
    assert false_positive not in result.stdout


def test_validate_doc_structure_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_doc_structure.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_doc_structure_fails_when_heading_missing(tmp_path):
    repo = copy_project(tmp_path)
    doc = repo / "docs" / "software-engineering" / "03_REQUIREMENTS.md"
    doc.write_text(doc.read_text(encoding="utf-8").replace("## Purpose", "## Goal"), encoding="utf-8")
    result = run_script(repo, "validate_doc_structure.py")
    assert result.returncode == 1
    assert "03_REQUIREMENTS.md missing heading: Purpose" in result.stdout


def test_validate_templates_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_templates.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_templates_fails_when_field_missing(tmp_path):
    repo = copy_project(tmp_path)
    template = repo / "templates" / "RISK_REGISTER.md"
    template.write_text(template.read_text(encoding="utf-8").replace("Contingency", "Fallback"), encoding="utf-8")
    result = run_script(repo, "validate_templates.py")
    assert result.returncode == 1
    assert "RISK_REGISTER.md missing field: Contingency" in result.stdout


def test_governance_metrics_outputs_valid_json(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "governance_metrics.py")
    assert result.returncode == 0
    metrics = json.loads(result.stdout)
    assert metrics["docs_count"] >= 18
    assert metrics["scripts_count"] >= 10
    assert "smell_warning_count" in metrics


def test_validate_skill_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_skill.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_skill_fails_when_reference_missing(tmp_path):
    repo = copy_project(tmp_path)
    ref = repo / ".agents" / "skills" / "software-engineering-governor" / "references" / "SE_CANON.md"
    ref.unlink()
    result = run_script(repo, "validate_skill.py")
    assert result.returncode == 1
    assert "missing reference: SE_CANON.md" in result.stdout


def test_check_adoption_passes_for_self(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "check_adoption.py", str(repo))
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_check_adoption_fails_for_missing_files(tmp_path):
    repo = copy_project(tmp_path)
    target = tmp_path / "target"
    target.mkdir()
    result = run_script(repo, "check_adoption.py", str(target))
    assert result.returncode == 1
    assert "missing adoption file: AGENTS.md" in result.stdout


def test_validate_smell_baseline_passes(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "validate_smell_baseline.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout


def test_validate_smell_baseline_fails_for_untriaged_warning(tmp_path):
    repo = copy_project(tmp_path)
    sample = repo / "new_warning.py"
    sample.write_text("timeout_seconds = " + "12" + "34" + "5", encoding="utf-8")
    result = run_script(repo, "validate_smell_baseline.py")
    assert result.returncode == 1
    assert "untriaged smell warning: new_warning.py: possible magic number" in result.stdout


def test_clean_artifacts_removes_generated_files(tmp_path):
    repo = copy_project(tmp_path)
    (repo / ".DS_Store").write_text("local", encoding="utf-8")
    (repo / ".pytest_cache").mkdir()
    pycache = repo / "scripts" / "__pycache__"
    pycache.mkdir()
    (pycache / "x.pyc").write_bytes(b"cache")
    result = run_script(repo, "clean_artifacts.py")
    assert result.returncode == 0
    assert "PASS" in result.stdout
    assert not (repo / ".DS_Store").exists()
    assert not (repo / ".pytest_cache").exists()
    assert not pycache.exists()


def test_validate_clean_package_fails_on_generated_files(tmp_path):
    repo = copy_project(tmp_path)
    (repo / ".DS_Store").write_text("local", encoding="utf-8")
    result = run_script(repo, "validate_clean_package.py")
    assert result.returncode == 1
    assert "clean package violation" in result.stdout


def test_extract_course_outline_returns_numbered_sections(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "extract_course_outline.py")
    assert result.returncode == 0
    outline = json.loads(result.stdout)
    sections = {item["section"] for item in outline}
    assert "1.2.1" in sections
    assert "17.9.6" in sections


def test_validate_course_coverage_fails_when_section_missing(tmp_path):
    repo = copy_project(tmp_path)
    coverage = repo / "docs" / "software-engineering" / "19_COURSE_SECTION_COVERAGE.md"
    text = coverage.read_text(encoding="utf-8")
    lines = [line for line in text.splitlines() if not line.startswith("| 17.9.6 |")]
    coverage.write_text("\n".join(lines) + "\n", encoding="utf-8")
    result = run_script(repo, "validate_course_coverage.py")
    assert result.returncode == 1
    assert "missing course section coverage: 17.9.6" in result.stdout


def test_validate_glossary_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_glossary.py").returncode == 0
    glossary = repo / "docs" / "GLOSSARY.md"
    glossary.write_text(glossary.read_text(encoding="utf-8").replace("Ambiguity risk", "Unclear risk"), encoding="utf-8")
    result = run_script(repo, "validate_glossary.py")
    assert result.returncode == 1
    assert "missing field: Ambiguity risk" in result.stdout


def test_validate_test_strategy_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_test_strategy.py").returncode == 0
    strategy = repo / "templates" / "TEST_STRATEGY_TEMPLATE.md"
    strategy.write_text(strategy.read_text(encoding="utf-8").replace("Mutation testing / mutation score", "Mutation score"), encoding="utf-8")
    result = run_script(repo, "validate_test_strategy.py")
    assert result.returncode == 1
    assert "missing field: Mutation testing / mutation score" in result.stdout


def test_complexity_report_outputs_json(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "complexity_report.py")
    assert result.returncode == 0
    rows = json.loads(result.stdout)
    assert isinstance(rows, list)
    assert any(row.get("function") == "main" for row in rows)


def test_test_matrix_coverage_report_detects_missing_category(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "test_matrix_coverage_report.py").returncode == 0
    matrix = repo / "templates" / "TEST_CASE_MATRIX.md"
    matrix.write_text("# Test Case Matrix\n\nNormal only\n", encoding="utf-8")
    result = run_script(repo, "test_matrix_coverage_report.py")
    assert result.returncode == 1
    assert "missing categories" in result.stdout


def test_validate_architecture_scenarios_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_architecture_scenarios.py").returncode == 0
    template = repo / "templates" / "ARCHITECTURE_SCENARIO_TEMPLATE.md"
    template.write_text(
        template.read_text(encoding="utf-8")
        .replace("Response measure", "Response metric")
        .replace("response measure", "response metric"),
        encoding="utf-8",
    )
    result = run_script(repo, "validate_architecture_scenarios.py")
    assert result.returncode == 1
    assert "missing field: Response measure" in result.stdout


def test_validate_project_management_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_project_management.py").returncode == 0
    roadmap = repo / "docs" / "project-management" / "ROADMAP.md"
    roadmap.write_text(roadmap.read_text(encoding="utf-8").replace("Owner", "Responsible"), encoding="utf-8")
    result = run_script(repo, "validate_project_management.py")
    assert result.returncode == 1
    assert "missing concept: owner" in result.stdout


def test_validate_ai_review_template_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_ai_review_template.py").returncode == 0
    template = repo / "templates" / "AI_USAGE_REVIEW_TEMPLATE.md"
    template.write_text(template.read_text(encoding="utf-8").replace("Human Review Yes/No", "Human Review"), encoding="utf-8")
    result = run_script(repo, "validate_ai_review_template.py")
    assert result.returncode == 1
    assert "missing field: Human review yes/no" in result.stdout


def test_validate_maintenance_docs_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_maintenance_docs.py").returncode == 0
    changelog = repo / "CHANGELOG.md"
    changelog.write_text(changelog.read_text(encoding="utf-8").replace("Upgrade Path", "Migration Path"), encoding="utf-8")
    result = run_script(repo, "validate_maintenance_docs.py")
    assert result.returncode == 1
    assert "CHANGELOG.md missing heading: Upgrade path" in result.stdout


def test_governance_metrics_includes_v04_fields(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "governance_metrics.py")
    assert result.returncode == 0
    metrics = json.loads(result.stdout)
    for key in [
        "course_section_count",
        "course_coverage_count",
        "course_coverage_missing_count",
        "clean_package_violation_count",
        "glossary_status",
        "maintenance_docs_count",
        "validators_count",
    ]:
        assert key in metrics


def test_validate_no_side_effects_detects_generated_artifacts(tmp_path):
    repo = copy_project(tmp_path)
    result = subprocess.run(
        [
            sys.executable,
            str(repo / "scripts" / "validate_no_side_effects.py"),
            "--",
            sys.executable,
            "-c",
            "from pathlib import Path; Path('__pycache__').mkdir(exist_ok=True)",
        ],
        cwd=repo,
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 1
    assert "side effect artifact created: __pycache__" in result.stdout


def test_governance_metrics_does_not_create_generated_artifacts(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "clean_artifacts.py").returncode == 0
    assert run_script(repo, "governance_metrics.py").returncode == 0
    result = run_script(repo, "validate_clean_package.py")
    assert result.returncode == 0


def test_package_release_creates_clean_zip(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "package_release.py").returncode == 0
    archive = repo / "dist" / "codex-se-governor-v0.5.zip"
    assert archive.exists()
    result = run_script(repo, "validate_release_archive.py", str(archive))
    assert result.returncode == 0


def test_validate_release_archive_fails_on_macos_artifact(tmp_path):
    repo = copy_project(tmp_path)
    archive = tmp_path / "bad.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        zf.writestr("__MACOSX/._file", "bad")
    result = run_script(repo, "validate_release_archive.py", str(archive))
    assert result.returncode == 1
    assert "generated artifact in archive" in result.stdout


def test_validate_course_semantic_coverage_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_course_semantic_coverage.py").returncode == 0
    semantic = repo / "docs" / "software-engineering" / "20_COURSE_SEMANTIC_COVERAGE.md"
    semantic.write_text(semantic.read_text(encoding="utf-8").replace("template-required", "weak-depth", 1), encoding="utf-8")
    result = run_script(repo, "validate_course_semantic_coverage.py")
    assert result.returncode == 1
    assert "invalid coverage depth" in result.stdout


def test_validate_course_outline_lock_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_course_outline_lock.py").returncode == 0
    lock = repo / "docs" / "software-engineering" / "COURSE_OUTLINE_LOCK.json"
    data = json.loads(lock.read_text(encoding="utf-8"))
    data[0]["title"] = "Changed title"
    lock.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    result = run_script(repo, "validate_course_outline_lock.py")
    assert result.returncode == 1
    assert "section title changed" in result.stdout


def test_validate_test_traceability_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_test_traceability.py").returncode == 0
    matrix = repo / "examples" / "example_feature_task" / "TEST_CASE_MATRIX.md"
    matrix.write_text(matrix.read_text(encoding="utf-8").replace("AC-005", "AC-999"), encoding="utf-8")
    result = run_script(repo, "validate_test_traceability.py")
    assert result.returncode == 1
    assert "acceptance criterion without test case" in result.stdout


def test_validate_complexity_thresholds_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_complexity_thresholds.py").returncode == 0
    baseline = repo / "docs" / "quality" / "COMPLEXITY_BASELINE.md"
    text = baseline.read_text(encoding="utf-8")
    filtered = "\n".join(line for line in text.splitlines() if "validate_test_traceability.py | main" not in line)
    baseline.write_text(filtered + "\n", encoding="utf-8")
    result = run_script(repo, "validate_complexity_thresholds.py")
    assert result.returncode == 1
    assert "unbaselined complexity threshold violation" in result.stdout


def test_validate_project_management_rejects_keyword_only_docs(tmp_path):
    repo = copy_project(tmp_path)
    weak = "version milestone deliverables owner monitoring risk rollback future target date cadence acceptance release criteria rollback criteria risk link"
    for doc in (repo / "docs" / "project-management").glob("*.md"):
        doc.write_text(weak, encoding="utf-8")
    result = run_script(repo, "validate_project_management.py")
    assert result.returncode == 1
    assert "lacks concrete rows or filled bullets" in result.stdout


def test_run_full_validation_passes_on_clean_repo_with_smoke_test(tmp_path):
    repo = copy_project(tmp_path)
    tests = repo / "tests"
    tests.mkdir()
    (tests / "test_smoke.py").write_text("def test_smoke():\n    assert True\n", encoding="utf-8")
    result = run_script(repo, "run_full_validation.py")
    assert result.returncode == 0
    assert "PASS full validation completed" in result.stdout


def test_governance_metrics_includes_v05_fields(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "governance_metrics.py")
    assert result.returncode == 0
    metrics = json.loads(result.stdout)
    for key in [
        "semantic_coverage_rows",
        "semantic_coverage_missing_count",
        "outline_lock_status",
        "no_side_effect_validation_status",
        "release_archive_validator_status",
        "test_traceability_status",
        "complexity_baseline_status",
        "complexity_threshold_violations",
        "ai_usage_example_status",
        "process_compliance_template_status",
        "full_validation_orchestrator_status",
    ]:
        assert key in metrics


def test_run_tests_clean_removes_pytest_artifacts(tmp_path):
    repo = copy_project(tmp_path)
    tests = repo / "tests"
    tests.mkdir()
    (tests / "test_smoke.py").write_text("def test_smoke():\n    assert True\n", encoding="utf-8")
    result = run_script(repo, "run_tests_clean.py")
    assert result.returncode == 0
    assert "PASS tests completed" in result.stdout
    assert run_script(repo, "validate_clean_package.py").returncode == 0


def test_validate_course_semantic_coverage_rejects_too_few_clusters(tmp_path):
    repo = copy_project(tmp_path)
    semantic = repo / "docs" / "software-engineering" / "20_COURSE_SEMANTIC_COVERAGE.md"
    semantic.write_text(
        "\n".join(semantic.read_text(encoding="utf-8").splitlines()[:10]) + "\n",
        encoding="utf-8",
    )
    result = run_script(repo, "validate_course_semantic_coverage.py")
    assert result.returncode == 1
    assert "minimum is 40" in result.stdout


def test_validate_course_semantic_coverage_rejects_missing_artifact(tmp_path):
    repo = copy_project(tmp_path)
    semantic = repo / "docs" / "software-engineering" / "20_COURSE_SEMANTIC_COVERAGE.md"
    semantic.write_text(semantic.read_text(encoding="utf-8").replace("templates/PROJECT_CONTEXT_TEMPLATE.md", "templates/MISSING_TEMPLATE.md", 1), encoding="utf-8")
    result = run_script(repo, "validate_course_semantic_coverage.py")
    assert result.returncode == 1
    assert "artifact path does not exist" in result.stdout


def test_validate_task_artifacts_passes_without_tasks_and_fails_incomplete_task(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_task_artifacts.py").returncode == 0
    task = repo / "tasks" / "bad-task"
    task.mkdir(parents=True)
    (task / "REQUIREMENTS.md").write_text("- FR-001: Do work\n- AC-001: It works\n", encoding="utf-8")
    result = run_script(repo, "validate_task_artifacts.py")
    assert result.returncode == 1
    assert "missing task artifact" in result.stdout


def test_validate_traceability_graph_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_traceability_graph.py").returncode == 0
    security = repo / "examples" / "example_feature_task" / "SECURITY_REVIEW.md"
    security.write_text(security.read_text(encoding="utf-8").replace("R-001", "R-999"), encoding="utf-8")
    final = repo / "examples" / "example_feature_task" / "FINAL_REPORT.md"
    final.write_text(final.read_text(encoding="utf-8").replace("R-001", "R-999"), encoding="utf-8")
    matrix = repo / "examples" / "example_feature_task" / "TEST_CASE_MATRIX.md"
    matrix.write_text(matrix.read_text(encoding="utf-8").replace("R-001", "R-999"), encoding="utf-8")
    result = run_script(repo, "validate_traceability_graph.py")
    assert result.returncode == 1
    assert "risk not linked" in result.stdout


def test_ai_review_score_and_evidence_failure(tmp_path):
    repo = copy_project(tmp_path)
    score_result = run_script(repo, "ai_review_score.py")
    assert score_result.returncode == 0
    rows = json.loads(score_result.stdout)
    assert rows[0]["score"] >= 8
    review = repo / "examples" / "example_feature_task" / "AI_USAGE_REVIEW.md"
    review.write_text("# AI Usage Review\n\n## AI Tool Used\nCodex\n", encoding="utf-8")
    result = run_script(repo, "validate_ai_review_evidence.py")
    assert result.returncode == 1
    assert "AI review score below" in result.stdout


def test_generate_governance_maturity_report_writes_report(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "generate_governance_maturity_report.py")
    assert result.returncode == 0
    report = repo / "docs" / "reports" / "GOVERNANCE_MATURITY_REPORT.md"
    assert report.exists()
    assert "Maturity Snapshot" in report.read_text(encoding="utf-8")


def test_validate_mutation_testing_plan_passes_and_fails(tmp_path):
    repo = copy_project(tmp_path)
    assert run_script(repo, "validate_mutation_testing_plan.py").returncode == 0
    plan = repo / "templates" / "MUTATION_TESTING_PLAN.md"
    plan.write_text(plan.read_text(encoding="utf-8").replace("Mutation Score Target", "Score Target"), encoding="utf-8")
    result = run_script(repo, "validate_mutation_testing_plan.py")
    assert result.returncode == 1
    assert "missing field: Mutation score target" in result.stdout


def test_validate_complexity_thresholds_rejects_missing_v06_field(tmp_path):
    repo = copy_project(tmp_path)
    baseline = repo / "docs" / "quality" / "COMPLEXITY_BASELINE.md"
    baseline.write_text(baseline.read_text(encoding="utf-8").replace("Target version", "Target release"), encoding="utf-8")
    result = run_script(repo, "validate_complexity_thresholds.py")
    assert result.returncode == 1
    assert "baseline missing field: Target version" in result.stdout


def test_governance_metrics_includes_v06_fields(tmp_path):
    repo = copy_project(tmp_path)
    result = run_script(repo, "governance_metrics.py")
    assert result.returncode == 0
    metrics = json.loads(result.stdout)
    for key in [
        "semantic_cluster_count",
        "semantic_cluster_minimum_pass",
        "task_artifact_validation_status",
        "traceability_graph_status",
        "ai_review_average_score",
        "complexity_exception_count",
        "complexity_over_20_count",
        "maturity_report_status",
        "mutation_plan_template_status",
        "deployment_template_status",
        "maintenance_task_template_status",
        "clean_test_wrapper_status",
    ]:
        assert key in metrics
